/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.studyopedia.firstjavaapplication;

/**
 *
 * @author ranji
 */
public class Firstjavaapplication {

    public static void main(String[] args) {
        System.out.println("My first java project");
    }
}
