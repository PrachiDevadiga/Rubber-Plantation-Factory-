/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.rubber_plantation_management_system;

/**
 *
 * @author ranji
 */
public class Rubber_plantation_management_system {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
